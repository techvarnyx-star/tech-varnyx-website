# Tech Varnyx Website Requirements Document

## 1. Application Overview

### 1.1 Application Name
Tech Varnyx Official Website

### 1.2 Application Description
A modern professional technology startup website for Tech Varnyx, an innovative IoT company focused on developing smart safety and automation products. The website showcases the company's vision, products (starting with the Smart Helmet Accident Detection System), technologies, and future innovations in IoT-based intelligent devices.

### 1.3 Target Language
English

## 2. Core Features

### 2.1 Home Page
- Display company name: Tech Varnyx
- Display tagline: Innovating the Future with Smart IoT Solutions
- Hero section showcasing IoT technology and smart devices
- Highlight the Smart Helmet product
- Two call-to-action buttons: Explore Products and Learn More

### 2.2 About Us Page
- Company introduction explaining Tech Varnyx as an innovative startup
- Vision statement: Build intelligent IoT systems that improve human safety and automation
- Mission statement: Develop affordable and reliable smart technology products

### 2.3 Products Page
- Display company product categories:
  - Smart Helmet Accident Detection System
  - Future IoT safety devices
  - Smart monitoring systems
  - Smart home automation products

### 2.4 Smart Helmet Product Page
- Detailed product features explanation:
  - Accident detection using MPU6050 sensor
  - Pulse monitoring using pulse sensor
  - Pressure detection using FSR sensor
  - GPS location tracking
  - Automatic SMS and emergency call alerts using GSM (SIM800L)

### 2.5 Technology Page
- Explain technologies used by the company:
  - Arduino
  - IoT sensors
  - GPS tracking
  - GSM communication
  - Embedded systems
  - Cloud and mobile integration

### 2.6 How It Works Page
- Step-by-step explanation of how IoT devices collect sensor data, process information, and send alerts during emergencies

### 2.7 Future Innovations Section
- Showcase upcoming IoT products and research ideas by Tech Varnyx

### 2.8 Product Gallery
- Display images of smart helmet prototype, circuits, sensors, and IoT devices

### 2.9 Contact Page
- Contact form for user inquiries
- Display contact information:
  - Phone: 9074883543
  - Email: techvarnyx@gmail.com
- Social media links:
  - Instagram: https://www.instagram.com/techvarnyx?igsh=MWdybnFzM3YyYmg4Zg==
  - Facebook: https://www.facebook.com/share/1MNh8GVuiV/
  - LinkedIn: https://www.linkedin.com/in/tech-varnyx-84b1613a1
  - Twitter (X): https://x.com/Techvarnyx
- All social media links should open in new tabs when clicked
- Social media links should be clickable and functional on mobile devices

### 2.10 Footer
- Display company name: Tech Varnyx
- Social media icons with links (same as contact page)
- All social media links should open in new tabs when clicked
- Social media links should be clickable and functional on mobile devices
- Copyright text: © Tech Varnyx – All Rights Reserved

## 3. Design Requirements

### 3.1 Visual Style
- Modern technology startup theme
- Color scheme: blue, black, and white
- Technology-themed icons and illustrations
- Clean UI similar to professional tech company websites

### 3.2 User Experience
- Smooth scrolling and animations
- Mobile-friendly responsive layout
- Sections highlighting innovation, IoT technology, and smart safety solutions
- Fully responsive across all devices
- All external links (social media) should be properly functional on mobile devices
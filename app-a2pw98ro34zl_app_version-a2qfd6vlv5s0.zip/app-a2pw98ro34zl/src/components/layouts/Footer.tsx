import React from 'react';
import { Link } from 'react-router-dom';
import { Cpu, Instagram, Facebook, Linkedin, Twitter, Phone, Mail } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="w-full border-t bg-background">
      <div className="container py-12 md:py-24">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4 lg:grid-cols-4">
          <div className="flex flex-col space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <Cpu className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold tracking-tight">Tech Varnyx</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              Innovating the Future with Smart IoT Solutions. Building intelligent IoT systems that improve human safety and automation.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://www.instagram.com/techvarnyx?igsh=MWdybnFzM3YyYmg4Zg=="
                target="_blank"
                rel="noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="https://www.facebook.com/share/1MNh8GVuiV/"
                target="_blank"
                rel="noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://www.linkedin.com/in/tech-varnyx-84b1613a1"
                target="_blank"
                rel="noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                <Linkedin className="h-5 w-5" />
              </a>
              <a
                href="https://x.com/Techvarnyx"
                target="_blank"
                rel="noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div className="flex flex-col space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider">Quick Links</h3>
            <nav className="flex flex-col space-y-2">
              <Link to="/about" className="text-sm text-muted-foreground hover:text-primary transition-colors">About Us</Link>
              <Link to="/products" className="text-sm text-muted-foreground hover:text-primary transition-colors">Products</Link>
              <Link to="/technology" className="text-sm text-muted-foreground hover:text-primary transition-colors">Technology</Link>
              <Link to="/how-it-works" className="text-sm text-muted-foreground hover:text-primary transition-colors">How It Works</Link>
            </nav>
          </div>

          <div className="flex flex-col space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider">Products</h3>
            <nav className="flex flex-col space-y-2">
              <Link to="/smart-helmet" className="text-sm text-muted-foreground hover:text-primary transition-colors">Smart Helmet</Link>
              <Link to="/products" className="text-sm text-muted-foreground hover:text-primary transition-colors">Future IoT Devices</Link>
              <Link to="/products" className="text-sm text-muted-foreground hover:text-primary transition-colors">Monitoring Systems</Link>
              <Link to="/products" className="text-sm text-muted-foreground hover:text-primary transition-colors">Home Automation</Link>
            </nav>
          </div>

          <div className="flex flex-col space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider">Contact Us</h3>
            <div className="flex flex-col space-y-2">
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4" />
                <span>9074883543</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4" />
                <span>techvarnyx@gmail.com</span>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Tech Varnyx – All Rights Reserved</p>
        </div>
      </div>
    </footer>
  );
};

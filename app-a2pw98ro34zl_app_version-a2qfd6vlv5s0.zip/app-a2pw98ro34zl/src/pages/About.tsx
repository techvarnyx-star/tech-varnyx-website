import React from 'react';
import { Target, Lightbulb, Users } from 'lucide-react';

const AboutHero = () => {
  return (
    <section className="bg-zinc-50 dark:bg-zinc-950 py-24 border-b">
      <div className="container text-center max-w-4xl mx-auto px-4">
        <h1 className="text-4xl font-extrabold tracking-tight lg:text-6xl mb-6">About Tech Varnyx</h1>
        <p className="text-xl text-muted-foreground">
          Tech Varnyx is a forward-thinking technology startup dedicated to developing smart safety and automation products.
          Our mission is to build intelligent IoT systems that improve human safety and simplify everyday life.
        </p>
      </div>
    </section>
  );
};

const VisionMission = () => {
  return (
    <section className="container py-24 px-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="flex flex-col space-y-4 p-8 rounded-2xl border bg-card transition-all hover:shadow-lg">
          <div className="rounded-full bg-primary/10 p-4 w-max">
            <Target className="h-8 w-8 text-primary" />
          </div>
          <h2 className="text-3xl font-bold">Our Vision</h2>
          <p className="text-lg text-muted-foreground">
            To be a global leader in providing innovative IoT-based intelligent devices. 
            We strive to build a future where smart technology acts as a seamless extension of human capability, ensuring safety and enhancing productivity.
          </p>
        </div>
        <div className="flex flex-col space-y-4 p-8 rounded-2xl border bg-card transition-all hover:shadow-lg">
          <div className="rounded-full bg-primary/10 p-4 w-max">
            <Lightbulb className="h-8 w-8 text-primary" />
          </div>
          <h2 className="text-3xl font-bold">Our Mission</h2>
          <p className="text-lg text-muted-foreground">
            To develop affordable, reliable, and accessible smart technology products. 
            We focus on creating robust IoT systems that use advanced sensors and real-time processing to solve real-world problems.
          </p>
        </div>
      </div>
    </section>
  );
};

const Introduction = () => {
  return (
    <section className="bg-zinc-50 dark:bg-zinc-950 py-24">
      <div className="container grid grid-cols-1 lg:grid-cols-2 gap-12 items-center px-4">
        <div className="relative rounded-2xl overflow-hidden shadow-xl aspect-video">
          <img
            src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_180415ef-4591-4af1-b4bc-9afe3b90700f.jpg"
            alt="Arduino Electronic Circuit"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="space-y-6">
          <h2 className="text-3xl font-bold">Innovation is in our DNA</h2>
          <p className="text-lg text-muted-foreground">
            Founded with the belief that technology should serve humanity, Tech Varnyx has quickly established itself as an innovative force in the IoT landscape. 
            Our team of engineers and designers work tirelessly to bring concepts to life using embedded systems, cloud integration, and advanced sensor technology.
          </p>
          <p className="text-lg text-muted-foreground">
            From our initial prototype of the Smart Helmet Accident Detection System to our upcoming range of home automation products, 
            every device we create is built with the user's safety and convenience at the forefront.
          </p>
          <div className="flex items-center space-x-4 p-4 border rounded-lg bg-white dark:bg-black/20">
            <Users className="h-10 w-10 text-primary" />
            <div>
              <p className="font-bold">Team of Experts</p>
              <p className="text-sm text-muted-foreground">Passionate about IoT and embedded systems.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default function About() {
  return (
    <div className="w-full">
      <AboutHero />
      <VisionMission />
      <Introduction />
    </div>
  );
}

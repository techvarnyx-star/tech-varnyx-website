import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, Zap, Cpu, Bell, ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative overflow-hidden bg-black text-white py-24 lg:py-32">
      <div className="absolute inset-0 z-0">
        <img
          src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_faed5ed0-dca2-4cbc-acd4-70fd5dedc7d1.jpg"
          alt="Modern IoT Technology Background"
          className="h-full w-full object-cover opacity-50"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
      </div>
      <div className="container relative z-10">
        <div className="max-w-3xl space-y-8">
          <Badge variant="outline" className="border-primary text-primary px-4 py-1 animate-pulse">
            Next Generation IoT Solutions
          </Badge>
          <h1 className="text-5xl font-extrabold tracking-tight lg:text-7xl">
            Innovating the Future with <span className="text-primary">Smart IoT Solutions</span>
          </h1>
          <p className="text-xl text-zinc-400 max-w-2xl">
            At Tech Varnyx, we build intelligent IoT systems that improve human safety and automation. 
            Join us in revolutionizing the way we interact with technology.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" asChild className="text-lg px-8">
              <Link to="/products">Explore Products</Link>
            </Button>
            <Button size="lg" variant="secondary" asChild className="text-lg px-8">
              <Link to="/about">Learn More</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

const FeatureCard = ({ icon: Icon, title, description }: { icon: any, title: string, description: string }) => (
  <div className="group flex flex-col items-center space-y-4 rounded-lg border bg-card p-8 text-center transition-all hover:shadow-lg hover:-translate-y-1">
    <div className="rounded-full bg-primary/10 p-4 transition-colors group-hover:bg-primary/20">
      <Icon className="h-8 w-8 text-primary" />
    </div>
    <h3 className="text-xl font-bold">{title}</h3>
    <p className="text-muted-foreground">{description}</p>
  </div>
);

const Features = () => {
  return (
    <section className="container py-24">
      <div className="flex flex-col items-center text-center space-y-4 mb-16">
        <h2 className="text-3xl font-bold lg:text-5xl">Our Smart Safety Solutions</h2>
        <p className="text-muted-foreground max-w-2xl text-lg">
          We combine cutting-edge sensors and embedded systems to create life-saving technologies and efficient automation.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <FeatureCard
          icon={Shield}
          title="Enhanced Safety"
          description="Advanced sensors monitor and detect accidents in real-time, providing immediate assistance when it matters most."
        />
        <FeatureCard
          icon={Cpu}
          title="Embedded Intelligence"
          description="Powering devices with Arduino and intelligent algorithms for reliable and fast processing."
        />
        <FeatureCard
          icon={Bell}
          title="Instant Alerts"
          description="Automatic SMS and emergency call notifications via GSM to ensure rapid response during emergencies."
        />
      </div>
    </section>
  );
};

const FeaturedProduct = () => {
  return (
    <section className="bg-zinc-50 dark:bg-zinc-950 py-24">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <Badge className="bg-primary/10 text-primary hover:bg-primary/10">Featured Product</Badge>
            <h2 className="text-4xl font-bold">Smart Helmet Accident Detection System</h2>
            <p className="text-lg text-muted-foreground">
              Our flagship product designed for riders. It uses MPU6050, Pulse, and FSR sensors to detect impact, monitor health, and ensure the rider is protected. 
              In case of an accident, it sends your precise GPS location to emergency contacts instantly.
            </p>
            <ul className="space-y-4">
              {[
                'Real-time Accident Detection',
                'Heart Rate & Health Monitoring',
                'GPS Location Tracking',
                'GSM Emergency Messaging'
              ].map((item, i) => (
                <li key={i} className="flex items-center space-x-3">
                  <Zap className="h-5 w-5 text-primary" />
                  <span className="font-medium">{item}</span>
                </li>
              ))}
            </ul>
            <Button asChild size="lg" className="group">
              <Link to="/smart-helmet">
                View Detailed Features
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
          </div>
          <div className="relative rounded-2xl overflow-hidden shadow-2xl">
            <img
              src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_b28f37a0-97b2-4ca9-bdfe-75368e07737a.jpg"
              alt="Smart Helmet Prototype"
              className="w-full h-auto object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default function Home() {
  return (
    <div className="w-full">
      <Hero />
      <Features />
      <FeaturedProduct />
      
      {/* Call to Action Section */}
      <section className="container py-24 border-t">
        <div className="rounded-3xl bg-primary px-8 py-16 text-center text-primary-foreground md:px-16 md:py-24">
          <h2 className="text-3xl font-bold lg:text-5xl mb-6">Ready to Experience the Future?</h2>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto mb-10">
            Tech Varnyx is committed to creating affordable and reliable smart technology products for everyone.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" variant="secondary" asChild className="text-lg px-8">
              <Link to="/contact">Contact Us Today</Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="text-lg px-8 border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
              <Link to="/products">See All Products</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}

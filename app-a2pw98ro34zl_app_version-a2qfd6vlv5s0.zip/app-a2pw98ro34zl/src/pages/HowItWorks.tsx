import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Cpu, Wifi, Bell, ShieldCheck, MapPin, Zap } from 'lucide-react';

const Step = ({ number, title, description, icon: Icon }: any) => (
  <div className="flex flex-col md:flex-row items-center md:items-start space-y-6 md:space-y-0 md:space-x-8 p-8 border rounded-3xl bg-card hover:shadow-lg transition-all">
    <div className="relative flex-shrink-0">
      <div className="rounded-2xl bg-primary/10 p-6 flex items-center justify-center">
        <Icon className="h-10 w-10 text-primary" />
      </div>
      <div className="absolute -top-3 -left-3 h-10 w-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg shadow-lg">
        {number}
      </div>
    </div>
    <div className="space-y-3 text-center md:text-left">
      <h3 className="text-2xl font-bold">{title}</h3>
      <p className="text-muted-foreground text-lg leading-relaxed">{description}</p>
    </div>
  </div>
);

export default function HowItWorks() {
  return (
    <div className="w-full">
      <section className="bg-zinc-50 dark:bg-zinc-950 py-24 px-4 border-b">
        <div className="container text-center max-w-4xl mx-auto">
          <Badge className="mb-4 bg-primary/10 text-primary hover:bg-primary/10 px-4 py-1">IoT Process Flow</Badge>
          <h1 className="text-4xl font-extrabold tracking-tight lg:text-6xl mb-6">How Our IoT Devices Work</h1>
          <p className="text-xl text-muted-foreground">
            A step-by-step look at the intelligence behind Tech Varnyx products.
          </p>
        </div>
      </section>

      <section className="container py-24 px-4">
        <div className="max-w-4xl mx-auto space-y-12">
          <Step
            number="1"
            icon={Zap}
            title="Sensor Data Collection"
            description="Our IoT devices use a suite of high-precision sensors (MPU6050, Pulse, FSR) to continuously monitor physical conditions and vital signs in real-time."
          />
          <Step
            number="2"
            icon={Cpu}
            title="Real-time Processing"
            description="The collected raw data is instantly processed by the Arduino microcontroller. Algorithms filter noise and analyze patterns to identify anomalies like a crash or health emergency."
          />
          <Step
            number="3"
            icon={MapPin}
            title="Location Acquisition"
            description="Once an emergency event is confirmed, the system immediately fetches the latest GPS coordinates from the Neo-6M module to pinpoint the exact location."
          />
          <Step
            number="4"
            icon={Bell}
            title="Emergency Alert Dispatch"
            description="The GSM module (SIM800L) is triggered to send an automated SMS with the GPS location and health status, followed by emergency calls to pre-configured contacts."
          />
          <Step
            number="5"
            icon={Wifi}
            title="Cloud Integration"
            description="Device data is also synced with our cloud backend for historical analysis, allowing users to track their safety logs and system performance over time."
          />
          <Step
            number="6"
            icon={ShieldCheck}
            title="Safety Confirmed"
            description="The entire cycle happens in less than 2 seconds, ensuring that medical assistance or emergency response is on its way without delay."
          />
        </div>
      </section>

      {/* Logic Visualization Section */}
      <section className="bg-zinc-50 dark:bg-zinc-950 py-24 border-t px-4">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl font-bold">Intelligent Alert Logic</h2>
              <p className="text-lg text-muted-foreground">
                Our proprietary logic ensures that alerts are only sent when a genuine emergency is detected. 
                Using a combination of threshold analysis and sensor fusion, we minimize false positives while maintaining 99.9% detection accuracy.
              </p>
              <div className="p-6 bg-white dark:bg-black/20 border rounded-2xl space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="h-3 w-3 rounded-full bg-green-500" />
                  <span className="font-medium">Normal State: Constant Monitoring</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="h-3 w-3 rounded-full bg-yellow-500 animate-pulse" />
                  <span className="font-medium">Anomaly Detected: High-Frequency Sampling</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="h-3 w-3 rounded-full bg-red-500 animate-ping" />
                  <span className="font-medium">Emergency Confirmed: Alert Triggered</span>
                </div>
              </div>
            </div>
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_faed5ed0-dca2-4cbc-acd4-70fd5dedc7d1.jpg"
                alt="Technology Visualization"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

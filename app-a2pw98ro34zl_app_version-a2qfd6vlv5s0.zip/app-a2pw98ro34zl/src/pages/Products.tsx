import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, Home, Eye, Layout, ArrowRight } from 'lucide-react';

const ProductCard = ({ title, category, description, icon: Icon, image, link }: any) => (
  <div className="group flex flex-col space-y-4 rounded-2xl border bg-card p-4 transition-all hover:shadow-xl hover:-translate-y-1">
    <div className="relative aspect-video overflow-hidden rounded-xl">
      <img
        src={image}
        alt={title}
        className="h-full w-full object-cover transition-transform group-hover:scale-105"
      />
      <div className="absolute top-3 left-3">
        <Badge className="bg-primary text-primary-foreground">{category}</Badge>
      </div>
    </div>
    <div className="flex-1 space-y-3 px-4 py-4">
      <div className="flex items-center space-x-2">
        <Icon className="h-5 w-5 text-primary" />
        <h3 className="text-xl font-bold">{title}</h3>
      </div>
      <p className="text-muted-foreground line-clamp-3">
        {description}
      </p>
      <div className="pt-4">
        {link ? (
          <Button asChild className="w-full group">
            <Link to={link}>
              Learn More
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </Button>
        ) : (
          <Button asChild variant="secondary" className="w-full">
            <Link to="/contact">Coming Soon - Inquire</Link>
          </Button>
        )}
      </div>
    </div>
  </div>
);

const categories = [
  {
    title: 'Smart Helmet Accident Detection',
    category: 'Safety IoT',
    description: 'A revolutionary helmet designed to detect accidents and monitor rider health in real-time. Features GPS tracking and automatic GSM alerts.',
    icon: Shield,
    image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_b28f37a0-97b2-4ca9-bdfe-75368e07737a.jpg',
    link: '/smart-helmet'
  },
  {
    title: 'Future IoT Safety Devices',
    category: 'Safety IoT',
    description: 'Upcoming wearable sensors and protective gear designed for industrial workers and adventure enthusiasts.',
    icon: Shield,
    image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_180415ef-4591-4af1-b4bc-9afe3b90700f.jpg',
    link: null
  },
  {
    title: 'Smart Monitoring Systems',
    category: 'Industrial IoT',
    description: 'Advanced monitoring systems using distributed sensors to track environmental conditions and machine health.',
    icon: Eye,
    image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_faed5ed0-dca2-4cbc-acd4-70fd5dedc7d1.jpg',
    link: null
  },
  {
    title: 'Smart Home Automation',
    category: 'Consumer IoT',
    description: 'Intelligent home systems that automate lighting, security, and climate control for a more comfortable life.',
    icon: Home,
    image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_e6a4b028-9fae-48c8-8922-358f3f35afb6.jpg',
    link: null
  }
];

export default function Products() {
  return (
    <div className="w-full">
      <section className="bg-zinc-50 dark:bg-zinc-950 py-24 px-4 border-b">
        <div className="container text-center max-w-4xl mx-auto">
          <Badge className="mb-4 bg-primary/10 text-primary hover:bg-primary/10 px-4 py-1">Our Product Portfolio</Badge>
          <h1 className="text-4xl font-extrabold tracking-tight lg:text-6xl mb-6">Innovative IoT Products</h1>
          <p className="text-xl text-muted-foreground">
            From smart wearables to industrial automation, we are building the future of intelligent devices.
          </p>
        </div>
      </section>

      <section className="container py-24 px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((product, index) => (
            <ProductCard key={index} {...product} />
          ))}
        </div>
      </section>

      {/* Product Gallery Feature */}
      <section className="bg-zinc-50 dark:bg-zinc-950 py-24 border-t px-4">
        <div className="container">
          <div className="flex flex-col items-center text-center space-y-4 mb-16">
            <h2 className="text-3xl font-bold lg:text-5xl">Innovation Gallery</h2>
            <p className="text-muted-foreground max-w-2xl text-lg">
              Explore the technology and prototypes behind our smart products.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_180415ef-4591-4af1-b4bc-9afe3b90700f.jpg',
              'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_faed5ed0-dca2-4cbc-acd4-70fd5dedc7d1.jpg',
              'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_b28f37a0-97b2-4ca9-bdfe-75368e07737a.jpg',
              'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_e6a4b028-9fae-48c8-8922-358f3f35afb6.jpg'
            ].map((src, i) => (
              <div key={i} className="relative aspect-square overflow-hidden rounded-xl shadow-md transition-all hover:scale-105">
                <img src={src} alt={`Gallery Image ${i + 1}`} className="h-full w-full object-cover" />
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Cpu, MapPin, Heart, MessageSquare, ShieldCheck, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

const FeatureItem = ({ icon: Icon, title, description }: any) => (
  <div className="flex flex-col space-y-3 p-6 border rounded-2xl bg-card hover:shadow-lg transition-all">
    <div className="rounded-full bg-primary/10 p-3 w-max">
      <Icon className="h-6 w-6 text-primary" />
    </div>
    <h3 className="text-xl font-bold">{title}</h3>
    <p className="text-muted-foreground">{description}</p>
  </div>
);

const SectionHeader = ({ title, subtitle }: { title: string, subtitle: string }) => (
  <div className="flex flex-col items-center text-center space-y-4 mb-16 px-4">
    <h2 className="text-3xl font-bold lg:text-5xl">{title}</h2>
    <p className="text-muted-foreground max-w-2xl text-lg">{subtitle}</p>
  </div>
);

export default function SmartHelmet() {
  return (
    <div className="w-full">
      {/* Product Hero */}
      <section className="bg-zinc-950 text-white py-24 relative overflow-hidden">
        <div className="container grid grid-cols-1 lg:grid-cols-2 gap-12 items-center px-4 relative z-10">
          <div className="space-y-8">
            <Badge className="bg-primary text-primary-foreground text-sm uppercase px-4 py-1">Flagship Technology</Badge>
            <h1 className="text-5xl font-extrabold tracking-tight lg:text-7xl">
              The <span className="text-primary">Smart Helmet</span>
            </h1>
            <p className="text-xl text-zinc-400">
              An advanced accident detection and health monitoring system built into a helmet. 
              Designed to protect riders and provide rapid emergency response through IoT innovation.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <Button size="lg" className="text-lg px-8" asChild>
                <Link to="/contact">Contact for Demo</Link>
              </Button>
              <Button size="lg" variant="secondary" className="text-lg px-8" asChild>
                <Link to="/technology">View Tech Specs</Link>
              </Button>
            </div>
          </div>
          <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-white/10 ring-8 ring-white/5">
            <img
              src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_b28f37a0-97b2-4ca9-bdfe-75368e07737a.jpg"
              alt="Smart Helmet Detailed View"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-primary/20 blur-[120px] rounded-full" />
      </section>

      {/* Core Features */}
      <section className="container py-24 px-4">
        <SectionHeader 
          title="Smart Features for Modern Riders"
          subtitle="Our helmet is packed with intelligent sensors and communication modules that work together to ensure your safety."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureItem
            icon={Zap}
            title="MPU6050 Accident Detection"
            description="Highly sensitive accelerometer and gyroscope to detect sudden impacts, falls, or unusual movement patterns instantly."
          />
          <FeatureItem
            icon={Heart}
            title="Pulse Monitoring"
            description="Built-in pulse sensor to track the heart rate of the rider, providing health insights and monitoring vital signs."
          />
          <FeatureItem
            icon={ShieldCheck}
            title="FSR Pressure Detection"
            description="Force Sensitive Resistor sensor ensures the helmet is being worn correctly and measures the intensity of a crash impact."
          />
          <FeatureItem
            icon={MapPin}
            title="GPS Location Tracking"
            description="Accurate GPS module (Neo-6M) providing real-time latitude and longitude coordinates during an emergency."
          />
          <FeatureItem
            icon={MessageSquare}
            title="GSM (SIM800L) Alerts"
            description="Automatic SMS and emergency calls to pre-set emergency contacts when an accident is detected."
          />
          <FeatureItem
            icon={Cpu}
            title="Arduino Powered"
            description="The system is driven by an efficient Arduino microcontroller, ensuring low-latency processing and reliability."
          />
        </div>
      </section>

      {/* Future Innovations Section inside page */}
      <section className="bg-zinc-50 dark:bg-zinc-950 py-24 border-t px-4">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative rounded-2xl overflow-hidden shadow-lg aspect-square max-w-md mx-auto">
              <img
                src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_180415ef-4591-4af1-b4bc-9afe3b90700f.jpg"
                alt="Electronic Circuit of Helmet"
                className="h-full w-full object-cover"
              />
            </div>
            <div className="space-y-6">
              <h2 className="text-3xl font-bold">Future Innovations</h2>
              <p className="text-lg text-muted-foreground">
                The Smart Helmet is just the beginning. Tech Varnyx is researching integrated Heads-Up Displays (HUD), blind-spot detection using ultrasonic sensors, 
                and V2V (Vehicle-to-Vehicle) communication for future iterations.
              </p>
              <p className="text-lg text-muted-foreground">
                Our goal is to make every helmet intelligent, affordable, and capable of saving lives worldwide.
              </p>
              <ul className="grid grid-cols-2 gap-4">
                {['AR Navigation', 'Voice Assistant', 'Blind Spot Alerts', 'Health Dashboard'].map((item, i) => (
                  <li key={i} className="flex items-center space-x-2">
                    <ShieldCheck className="h-5 w-5 text-primary" />
                    <span className="font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

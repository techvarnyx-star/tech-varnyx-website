import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Cpu, Satellite, Radio, HardDrive, Smartphone, Cloud, Layers } from 'lucide-react';

const TechCard = ({ icon: Icon, title, description, features }: any) => (
  <div className="flex flex-col space-y-4 p-8 border rounded-2xl bg-card transition-all hover:shadow-lg">
    <div className="rounded-full bg-primary/10 p-4 w-max">
      <Icon className="h-8 w-8 text-primary" />
    </div>
    <h3 className="text-2xl font-bold">{title}</h3>
    <p className="text-muted-foreground text-lg">{description}</p>
    <ul className="space-y-2 mt-4">
      {features.map((feature: string, i: number) => (
        <li key={i} className="flex items-center space-x-2 text-sm">
          <Layers className="h-4 w-4 text-primary" />
          <span>{feature}</span>
        </li>
      ))}
    </ul>
  </div>
);

export default function Technology() {
  return (
    <div className="w-full">
      <section className="bg-zinc-50 dark:bg-zinc-950 py-24 px-4 border-b">
        <div className="container text-center max-w-4xl mx-auto">
          <Badge className="mb-4 bg-primary/10 text-primary hover:bg-primary/10 px-4 py-1">Our Technology Stack</Badge>
          <h1 className="text-4xl font-extrabold tracking-tight lg:text-6xl mb-6">Built on Intelligence</h1>
          <p className="text-xl text-muted-foreground">
            Explore the embedded systems and communication technologies that power Tech Varnyx products.
          </p>
        </div>
      </section>

      <section className="container py-24 px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <TechCard
            icon={Cpu}
            title="Arduino Ecosystem"
            description="At the core of our devices lies the Arduino platform, providing reliable real-time processing and extensive sensor compatibility."
            features={[
              'Atmel Microcontrollers',
              'Real-time Interrupts',
              'Low Power Consumption',
              'Easy Scalability'
            ]}
          />
          <TechCard
            icon={Satellite}
            title="GPS Tracking"
            description="We integrate precise GPS modules like the Neo-6M to provide high-accuracy location tracking even in challenging environments."
            features={[
              'NMEA Data Processing',
              'Fast Satellite Locking',
              'Coordinate Precision',
              'Real-time Velocity Data'
            ]}
          />
          <TechCard
            icon={Radio}
            title="GSM Communication"
            description="Our devices use GSM modules (SIM800L) to communicate over cellular networks for calls and SMS alerts."
            features={[
              'Quad-band GPRS',
              'Emergency SMS Sending',
              'Automatic Call Triggering',
              'Reliable Cellular Link'
            ]}
          />
          <TechCard
            icon={HardDrive}
            title="IoT Sensors"
            description="We use a wide array of specialized sensors for accident detection, environmental monitoring, and health tracking."
            features={[
              'MPU6050 Accelerometer',
              'Pulse/Heart-rate Sensors',
              'FSR Pressure Sensors',
              'Ultrasonic Sensors'
            ]}
          />
          <TechCard
            icon={Smartphone}
            title="Mobile Integration"
            description="Seamless connectivity with mobile devices allows users to monitor their IoT products and receive alerts on the go."
            features={[
              'Bluetooth Connectivity',
              'Android/iOS Integration',
              'Mobile Alert Dashboard',
              'User Customization'
            ]}
          />
          <TechCard
            icon={Cloud}
            title="Cloud Processing"
            description="Data collected from our IoT devices is processed and analyzed in the cloud for predictive safety and analytics."
            features={[
              'Real-time Data Streams',
              'Historical Tracking',
              'Data Security',
              'Predictive Maintenance'
            ]}
          />
        </div>
      </section>

      {/* Tech Visualization Section */}
      <section className="bg-zinc-950 text-white py-24 border-t px-4">
        <div className="container grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold lg:text-5xl">Embedded Excellence</h2>
            <p className="text-lg text-zinc-400">
              We specialize in embedded systems design, from circuit board layouts to firmware optimization. 
              Our technology stack ensures that every device is fast, responsive, and robust enough for real-world conditions.
            </p>
            <div className="grid grid-cols-2 gap-4 pt-6">
              <div className="border border-white/10 rounded-xl p-4 bg-white/5">
                <p className="text-primary font-bold text-2xl">99.9%</p>
                <p className="text-sm text-zinc-500">Alert Reliability</p>
              </div>
              <div className="border border-white/10 rounded-xl p-4 bg-white/5">
                <p className="text-primary font-bold text-2xl">&lt; 1s</p>
                <p className="text-sm text-zinc-500">Processing Delay</p>
              </div>
            </div>
          </div>
          <div className="relative rounded-2xl overflow-hidden shadow-2xl group">
             <img
              src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_180415ef-4591-4af1-b4bc-9afe3b90700f.jpg"
              alt="Tech Visual"
              className="w-full h-full object-cover transition-transform group-hover:scale-105"
            />
          </div>
        </div>
      </section>
    </div>
  );
}

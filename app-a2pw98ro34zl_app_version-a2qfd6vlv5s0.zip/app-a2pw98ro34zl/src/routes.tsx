import Home from './pages/Home';
import About from './pages/About';
import Products from './pages/Products';
import SmartHelmet from './pages/SmartHelmet';
import Technology from './pages/Technology';
import HowItWorks from './pages/HowItWorks';
import Contact from './pages/Contact';
import { MainLayout } from './components/layouts/MainLayout';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <MainLayout><Home /></MainLayout>
  },
  {
    name: 'About',
    path: '/about',
    element: <MainLayout><About /></MainLayout>
  },
  {
    name: 'Products',
    path: '/products',
    element: <MainLayout><Products /></MainLayout>
  },
  {
    name: 'Smart Helmet',
    path: '/smart-helmet',
    element: <MainLayout><SmartHelmet /></MainLayout>
  },
  {
    name: 'Technology',
    path: '/technology',
    element: <MainLayout><Technology /></MainLayout>
  },
  {
    name: 'How It Works',
    path: '/how-it-works',
    element: <MainLayout><HowItWorks /></MainLayout>
  },
  {
    name: 'Contact',
    path: '/contact',
    element: <MainLayout><Contact /></MainLayout>
  }
];

export default routes;
